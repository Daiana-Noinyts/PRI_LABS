#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "BTTask_ForestLookAround.generated.h"

UCLASS()
class FOREST_API UBTTask_ForestLookAround : public UBTTaskNode
{
	GENERATED_BODY()

public:
	UBTTask_ForestLookAround();

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Observe")
	float LookAroundAngle = 60.0f;
};
