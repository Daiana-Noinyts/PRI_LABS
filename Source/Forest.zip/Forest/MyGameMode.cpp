#include "MyGameMode.h"
#include "ForestHUD.h"
#include "HunterCharacter.h"
#include "Projectile.h"

AMyGameMode::AMyGameMode()
{
	HUDClass = AForestHUD::StaticClass();
	DefaultPawnClass = AHunterCharacter::StaticClass();
}

