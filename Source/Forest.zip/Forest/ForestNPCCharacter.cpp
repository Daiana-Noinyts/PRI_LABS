#include "ForestNPCCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "Components/WidgetComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "AIController.h"
#include "TimerManager.h"

AForestNPCCharacter::AForestNPCCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	// Weapon mesh attached to character skeleton socket
	WeaponMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WeaponMeshComponent"));
	WeaponMeshComponent->SetupAttachment(GetMesh(), WeaponSocketName);
	WeaponMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	WeaponMeshComponent->SetCastShadow(true);

	// Dedicated overhead Health Bar widget component
	HealthWidgetComponent = CreateDefaultSubobject<UWidgetComponent>(TEXT("HealthWidgetComponent"));
	HealthWidgetComponent->SetupAttachment(RootComponent);
	HealthWidgetComponent->SetRelativeLocation(FVector(0.0f, 0.0f, 110.0f));
	HealthWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
	HealthWidgetComponent->SetDrawSize(FVector2D(140.0f, 18.0f));

	// Movement settings
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->bUseControllerDesiredRotation = true;
		MoveComp->bOrientRotationToMovement = false;
		MoveComp->MaxWalkSpeed = WalkSpeed;
		MoveComp->RotationRate = FRotator(0.0f, 360.0f, 0.0f);
	}

	bUseControllerRotationYaw = false;
}

void AForestNPCCharacter::BeginPlay()
{
	Super::BeginPlay();

	CurrentHealth = MaxHealth;

	// Attach weapon properly to socket if socket exists
	if (GetMesh() && WeaponMeshComponent)
	{
		if (GetMesh()->DoesSocketExist(WeaponSocketName))
		{
			WeaponMeshComponent->AttachToComponent(GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, WeaponSocketName);
		}
	}

	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->MaxWalkSpeed = WalkSpeed;
	}

	BP_OnHealthChanged(CurrentHealth, MaxHealth);
}

void AForestNPCCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AForestNPCCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

ETeamAttitude::Type AForestNPCCharacter::GetTeamAttitudeTowards(const AActor& Other) const
{
	if (const IGenericTeamAgentInterface* TeamAgent = Cast<IGenericTeamAgentInterface>(&Other))
	{
		// Player is Team 0 -> Hostile
		if (TeamAgent->GetGenericTeamId() == FGenericTeamId(0))
		{
			return ETeamAttitude::Hostile;
		}
		// Fellow NPCs or Team 1 -> Friendly
		if (TeamAgent->GetGenericTeamId() == GetGenericTeamId())
		{
			return ETeamAttitude::Friendly;
		}
	}
	return ETeamAttitude::Neutral;
}

void AForestNPCCharacter::Walk()
{
	bIsRunning = false;
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		const float TargetSpeed = bIsInSmoke ? (WalkSpeed * 0.45f) : WalkSpeed;
		MoveComp->MaxWalkSpeed = TargetSpeed;
	}
}

void AForestNPCCharacter::Run()
{
	bIsRunning = true;
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		const float TargetSpeed = bIsInSmoke ? (RunSpeed * 0.45f) : RunSpeed;
		MoveComp->MaxWalkSpeed = TargetSpeed;
	}
}

void AForestNPCCharacter::SetSpeedCustom(float InSpeed)
{
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->MaxWalkSpeed = bIsInSmoke ? (InSpeed * 0.45f) : InSpeed;
	}
}

float AForestNPCCharacter::CalculateDodgeProbability(float AttackerDistance) const
{
	// Success probability increases proportionally to distance of player's attack!
	const float ClampedDist = FMath::Clamp(AttackerDistance, MinDodgeDistance, MaxDodgeDistance);
	const float Alpha = (ClampedDist - MinDodgeDistance) / FMath::Max(MaxDodgeDistance - MinDodgeDistance, 1.0f);
	return FMath::Lerp(MinDodgeProbability, MaxDodgeProbability, Alpha);
}

bool AForestNPCCharacter::TryDodgeAttack(AActor* Attacker, const FVector& AttackOrigin)
{
	if (bIsDodging || bIsDying)
	{
		return false;
	}

	const float Distance = FVector::Dist(GetActorLocation(), AttackOrigin);
	const float DodgeProb = CalculateDodgeProbability(Distance);
	const float Roll = FMath::FRand();

	UE_LOG(LogTemp, Warning, TEXT("[Dodge] Dist=%.0f Prob=%.2f Roll=%.2f"), Distance, DodgeProb, Roll);

	if (Roll <= DodgeProb)
	{
		// Dodge successful!
		bIsDodging = true;

		// Calculate lateral evade direction
		const FVector ThreatDir = (GetActorLocation() - AttackOrigin).GetSafeNormal2D();
		const FVector RightDir = FVector::CrossProduct(ThreatDir, FVector::UpVector);
		// Randomly dodge left or right
		const float SideSign = (FMath::RandBool()) ? 1.0f : -1.0f;
		const FVector DodgeDirection = (RightDir * SideSign + ThreatDir * 0.3f).GetSafeNormal();

		// Physical impulse / dash
		LaunchCharacter(DodgeDirection * DodgeImpulseStrength + FVector(0.0f, 0.0f, 150.0f), true, false);

		if (DodgeMontage)
		{
			PlayAnimMontage(DodgeMontage);
		}

		BP_OnDodgeExecuted(DodgeDirection);
		OnNPCDodge.Broadcast(DodgeDirection, true);

		// Reset dodge state after recovery window
		GetWorldTimerManager().SetTimer(DodgeResetTimerHandle, this, &AForestNPCCharacter::ResetDodgeState, 0.9f, false);
		return true;
	}

	OnNPCDodge.Broadcast(FVector::ZeroVector, false);
	return false;
}

void AForestNPCCharacter::ResetDodgeState()
{
	UE_LOG(LogTemp, Warning, TEXT("[Dodge] ResetDodgeState called, bIsDodging set to false"));
	bIsDodging = false;
}

float AForestNPCCharacter::TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	UE_LOG(LogTemp, Warning, TEXT("[NPC] TakeDamage: dmg=%.1f dodging=%d dying=%d"),
		DamageAmount, bIsDodging, bIsDying);

	if (bIsDying)
	{
		return 0.0f;
	}

	// Use the SHOOTER's position for distance, not the projectile's
	FVector AttackOrigin = GetActorLocation();
	AActor* Attacker = nullptr;
	if (EventInstigator && EventInstigator->GetPawn())
	{
		Attacker = EventInstigator->GetPawn();
		AttackOrigin = Attacker->GetActorLocation();
	}
	else if (DamageCauser)
	{
		Attacker = DamageCauser;
		AttackOrigin = DamageCauser->GetActorLocation();
	}

	// Check if NPC successfully dodges incoming attack
	if (TryDodgeAttack(Attacker, AttackOrigin))
	{
		// Damage completely avoided via agile dodge!
		return 0.0f;
	}

	const float ActualDamage = Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);
	CurrentHealth = FMath::Clamp(CurrentHealth - ActualDamage, 0.0f, MaxHealth);
	BP_OnHealthChanged(CurrentHealth, MaxHealth);

	if (CurrentHealth <= 0.0f)
	{
		Die();
	}
	else if (HitMontage && !bIsDodging)
	{
		PlayAnimMontage(HitMontage);
	}

	return ActualDamage;
}

void AForestNPCCharacter::AttackPlayer(AActor* TargetPlayer)
{
	if (!bCanAttack || bIsDying || bIsDodging || !TargetPlayer)
	{
		return;
	}

	bCanAttack = false;

	if (AttackMontage)
	{
		PlayAnimMontage(AttackMontage);
	}

	BP_OnAttackExecuted();

	// Deal minor damage to player when in weapon range
	UGameplayStatics::ApplyDamage(TargetPlayer, AttackDamage, GetController(), this, UDamageType::StaticClass());

	GetWorldTimerManager().SetTimer(AttackCooldownTimerHandle, this, &AForestNPCCharacter::ResetAttackCooldown, AttackCooldown, false);
}

void AForestNPCCharacter::ResetAttackCooldown()
{
	bCanAttack = true;
}

void AForestNPCCharacter::Die()
{
	if (bIsDying)
	{
		return;
	}

	bIsDying = true;
	GetCapsuleComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);
	GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Block);

	if (DeathMontage)
	{
		PlayAnimMontage(DeathMontage);
	}

	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->DisableMovement();
		MoveComp->StopMovementImmediately();
	}

	OnNPCDeath.Broadcast(this);
	SetLifeSpan(8.0f);
}

void AForestNPCCharacter::ApplySmokeDebuff(float SlowFactor, bool bBlindSight)
{
	bIsInSmoke = true;
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->MaxWalkSpeed = (bIsRunning ? RunSpeed : WalkSpeed) * SlowFactor;
	}
	BP_OnSmokeEntered();
}

void AForestNPCCharacter::RemoveSmokeDebuff()
{
	bIsInSmoke = false;
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->MaxWalkSpeed = bIsRunning ? RunSpeed : WalkSpeed;
	}
	BP_OnSmokeExited();
}
