#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GenericTeamAgentInterface.h"
#include "ForestNPCCharacter.generated.h"

class UWidgetComponent;
class UAnimMontage;
class AAIController;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNPCDeathSignature, AForestNPCCharacter*, DeadCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnNPCDodgeSignature, FVector, DodgeDirection, bool, bSuccess);

UCLASS()
class FOREST_API AForestNPCCharacter : public ACharacter, public IGenericTeamAgentInterface
{
	GENERATED_BODY()

public:
	AForestNPCCharacter();

	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;

	// IGenericTeamAgentInterface
	virtual FGenericTeamId GetGenericTeamId() const override { return FGenericTeamId(1); } // 1 = NPC Team
	virtual ETeamAttitude::Type GetTeamAttitudeTowards(const AActor& Other) const override;

	// Movement states
	UFUNCTION(BlueprintCallable, Category = "NPC|Movement")
	void Walk();

	UFUNCTION(BlueprintCallable, Category = "NPC|Movement")
	void Run();

	UFUNCTION(BlueprintCallable, Category = "NPC|Movement")
	void SetSpeedCustom(float InSpeed);

	// Combat
	UFUNCTION(BlueprintCallable, Category = "NPC|Combat")
	void AttackPlayer(AActor* TargetPlayer);

	UFUNCTION(BlueprintCallable, Category = "NPC|Combat")
	bool TryDodgeAttack(AActor* Attacker, const FVector& AttackOrigin);

	UFUNCTION(BlueprintCallable, Category = "NPC|Combat")
	float CalculateDodgeProbability(float AttackerDistance) const;

	UFUNCTION(BlueprintCallable, Category = "NPC|Combat")
	void Die();

	// Smoke / Hazard debuff (Obstacle system)
	UFUNCTION(BlueprintCallable, Category = "NPC|Obstacle")
	void ApplySmokeDebuff(float SlowFactor = 0.45f, bool bBlindSight = true);

	UFUNCTION(BlueprintCallable, Category = "NPC|Obstacle")
	void RemoveSmokeDebuff();

	// Stats Getters
	UFUNCTION(BlueprintPure, Category = "NPC|Stats")
	float GetHealth() const { return CurrentHealth; }

	UFUNCTION(BlueprintPure, Category = "NPC|Stats")
	float GetMaxHealth() const { return MaxHealth; }

	UFUNCTION(BlueprintPure, Category = "NPC|Stats")
	float GetHealthPercent() const { return MaxHealth > 0.0f ? CurrentHealth / MaxHealth : 0.0f; }

	UFUNCTION(BlueprintPure, Category = "NPC|Combat")
	bool IsDying() const { return bIsDying; }

	UFUNCTION(BlueprintPure, Category = "NPC|Combat")
	bool IsDodging() const { return bIsDodging; }

	UFUNCTION(BlueprintPure, Category = "NPC|Obstacle")
	bool IsInSmoke() const { return bIsInSmoke; }

	UFUNCTION(BlueprintPure, Category = "NPC|Combat")
	float GetWeaponEffectiveRange() const { return WeaponEffectiveRange; }

protected:
	virtual void BeginPlay() override;

	// Components
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Components")
	UStaticMeshComponent* WeaponMeshComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Components")
	UWidgetComponent* HealthWidgetComponent;

	// Socket for weapon attachment
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat")
	FName WeaponSocketName = FName("WeaponSocket");

	// Stats
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Stats")
	float CurrentHealth = 120.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Stats")
	float MaxHealth = 120.0f;

	// Movement Speeds
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Movement")
	float WalkSpeed = 160.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Movement")
	float RunSpeed = 580.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Movement")
	bool bIsRunning = false;

	// Combat parameters
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat")
	float WeaponEffectiveRange = 220.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat")
	float AttackDamage = 12.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat")
	float AttackCooldown = 1.2f;

	// Dodge parameters
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat|Dodge")
	float MinDodgeDistance = 250.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat|Dodge")
	float MaxDodgeDistance = 2200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat|Dodge")
	float MinDodgeProbability = 0.15f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat|Dodge")
	float MaxDodgeProbability = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Combat|Dodge")
	float DodgeImpulseStrength = 600.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Combat|Dodge")
	bool bIsDodging = false;

	// Obstacle / Smoke status
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Obstacle")
	bool bIsInSmoke = false;

	// Montages
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Animations")
	UAnimMontage* AttackMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Animations")
	UAnimMontage* DodgeMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Animations")
	UAnimMontage* HitMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NPC|Animations")
	UAnimMontage* DeathMontage;

	// Death state
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "NPC|Combat")
	bool bIsDying = false;

	// Events for Blueprint hooks
	UPROPERTY(BlueprintAssignable, Category = "NPC|Events")
	FOnNPCDeathSignature OnNPCDeath;

	UPROPERTY(BlueprintAssignable, Category = "NPC|Events")
	FOnNPCDodgeSignature OnNPCDodge;

	UFUNCTION(BlueprintImplementableEvent, Category = "NPC|Events")
	void BP_OnAttackExecuted();

	UFUNCTION(BlueprintImplementableEvent, Category = "NPC|Events")
	void BP_OnDodgeExecuted(const FVector& DodgeDir);

	UFUNCTION(BlueprintImplementableEvent, Category = "NPC|Events")
	void BP_OnSmokeEntered();

	UFUNCTION(BlueprintImplementableEvent, Category = "NPC|Events")
	void BP_OnSmokeExited();

	UFUNCTION(BlueprintImplementableEvent, Category = "NPC|Events")
	void BP_OnHealthChanged(float NewHealth, float InMaxHealth);

private:
	FTimerHandle DodgeResetTimerHandle;
	FTimerHandle AttackCooldownTimerHandle;
	bool bCanAttack = true;

	void ResetDodgeState();
	void ResetAttackCooldown();
};
