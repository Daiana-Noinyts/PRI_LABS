#include "ForestAIController.h"
#include "ForestNPCCharacter.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BlackboardData.h"

AForestAIController::AForestAIController()
{
	PrimaryActorTick.bCanEverTick = true;

	AIPerceptionComp = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("PerceptionComponent"));
	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));

	if (SightConfig)
	{
		SightConfig->SightRadius = 2600.0f;
		SightConfig->LoseSightRadius = 3100.0f;
		SightConfig->PeripheralVisionAngleDegrees = 85.0f;
		SightConfig->SetMaxAge(5.0f);
		SightConfig->AutoSuccessRangeFromLastSeenLocation = 400.0f;

		// Detect Enemies (Player) and Neutrals
		SightConfig->DetectionByAffiliation.bDetectEnemies = true;
		SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
		SightConfig->DetectionByAffiliation.bDetectFriendlies = false;

		AIPerceptionComp->ConfigureSense(*SightConfig);
		AIPerceptionComp->SetDominantSense(SightConfig->GetSenseImplementation());
	}
}

void AForestAIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	ControlledNPC = Cast<AForestNPCCharacter>(InPawn);

	if (AIPerceptionComp)
	{
		AIPerceptionComp->OnTargetPerceptionUpdated.AddDynamic(this, &AForestAIController::OnTargetPerceptionUpdated);
	}

	if (BehaviorTreeAsset)
	{
		RunBehaviorTree(BehaviorTreeAsset);
	}
}

void AForestAIController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	UBlackboardComponent* BB = GetBlackboardComponent();
	if (!BB || !ControlledNPC)
	{
		return;
	}

	// Sync Death state
	if (ControlledNPC->IsDying())
	{
		BB->SetValueAsBool(IsDyingKey, true);
		ClearFocus(EAIFocusPriority::Gameplay);
		return;
	}

	// Sync Dodge & Smoke states
	BB->SetValueAsBool(IsDodgingKey, ControlledNPC->IsDodging());
	BB->SetValueAsBool(IsInSmokeKey, ControlledNPC->IsInSmoke());

	// If currently in sight, continuously refresh player's last known location
	if (bHasLineOfSight && PerceivedActor)
	{
		LastLocationElapsed += DeltaTime;
		if (LastLocationElapsed >= LastLocationUpdateTime)
		{
			LastLocationElapsed = 0.0f;
			BB->SetValueAsVector(LastKnownLocationKey, PerceivedActor->GetActorLocation());
		}

		// Update effective weapon range flag
		const float DistToTarget = FVector::Dist(ControlledNPC->GetActorLocation(), PerceivedActor->GetActorLocation());
		const bool bInRange = DistToTarget <= ControlledNPC->GetWeaponEffectiveRange();
		BB->SetValueAsBool(IsEffectiveRangeKey, bInRange);
	}

	// If player broke line of sight, track memory decay timer
	if (!bHasLineOfSight && PerceivedActor)
	{
		TargetLostElapsed += DeltaTime;
		if (TargetLostElapsed >= TargetLostTime)
		{
			// NPC has "forgotten" the player and returns to patrolling
			PerceivedActor = nullptr;
			TargetLostElapsed = 0.0f;
			BB->SetValueAsObject(DetectedEnemyKey, nullptr);
			BB->SetValueAsBool(HasLineOfSightKey, false);
			BB->SetValueAsBool(IsEffectiveRangeKey, false);
			ClearFocus(EAIFocusPriority::Gameplay);
		}
	}
}

ETeamAttitude::Type AForestAIController::GetTeamAttitudeTowards(const AActor& Other) const
{
	if (const IGenericTeamAgentInterface* OtherTeamAgent = Cast<IGenericTeamAgentInterface>(&Other))
	{
		// Player Team = 0 -> Hostile
		if (OtherTeamAgent->GetGenericTeamId() == FGenericTeamId(0))
		{
			return ETeamAttitude::Hostile;
		}
		// NPCs Team = 1 -> Friendly
		if (OtherTeamAgent->GetGenericTeamId() == FGenericTeamId(1))
		{
			return ETeamAttitude::Friendly;
		}
	}
	return ETeamAttitude::Neutral;
}

void AForestAIController::OnTargetPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
	UBlackboardComponent* BB = GetBlackboardComponent();
	if (!BB || !Actor)
	{
		return;
	}

	// Verify target is hostile (player)
	if (GetTeamAttitudeTowards(*Actor) != ETeamAttitude::Hostile)
	{
		return;
	}

	bHasLineOfSight = Stimulus.WasSuccessfullySensed();
	BB->SetValueAsBool(HasLineOfSightKey, bHasLineOfSight);

	if (bHasLineOfSight)
	{
		PerceivedActor = Actor;
		TargetLostElapsed = 0.0f;
		BB->SetValueAsObject(DetectedEnemyKey, PerceivedActor);
		BB->SetValueAsVector(LastKnownLocationKey, Actor->GetActorLocation());
		SetFocus(Actor);
	}
	else
	{
		// Store last sensed location when line of sight is broken so Search branch can navigate there
		BB->SetValueAsVector(LastKnownLocationKey, Stimulus.StimulusLocation);
		ClearFocus(EAIFocusPriority::Gameplay);
	}
}

void AForestAIController::SetInSmoke(bool bInSmoke)
{
	if (UBlackboardComponent* BB = GetBlackboardComponent())
	{
		BB->SetValueAsBool(IsInSmokeKey, bInSmoke);
	}
}
