#include "HunterCharacter.h"
#include "Projectile.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Blueprint/UserWidget.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "UObject/UObjectIterator.h"
#include "Components/ProgressBar.h"
#include "Components/PanelWidget.h"
#include "UObject/ConstructorHelpers.h"

// Sets default values
AHunterCharacter::AHunterCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
	check(CameraComponent != nullptr);
	CameraComponent->SetupAttachment(CastChecked<USceneComponent, UCapsuleComponent>(GetCapsuleComponent()));
	CameraComponent->bUsePawnControlRotation = true;

	GetMesh()->SetupAttachment(CameraComponent);

	GunMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("GunMeshComponent"));
	GunMeshComponent->bCastDynamicShadow = false;
	GunMeshComponent->CastShadow = false;
	GunMeshComponent->SetupAttachment(GetMesh(), TEXT("HandGrip_l"));

	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->bEnablePhysicsInteraction = true;
		MoveComp->PushForceFactor = 750000.0f;
		MoveComp->InitialPushForceFactor = 500000.0f;
	}

	static ConstructorHelpers::FClassFinder<UUserWidget> HUDWidgetFinder(TEXT("/Game/UI/HUD_Widget"));
	if (HUDWidgetFinder.Succeeded())
	{
		HUDWidgetClass = HUDWidgetFinder.Class;
	}
}


// Called when the game starts or when spawned
void AHunterCharacter::BeginPlay()
{
	Super::BeginPlay();

	GetMesh()->AttachToComponent(CameraComponent, FAttachmentTransformRules::SnapToTargetNotIncludingScale);

	if (HUDWidgetClass && !HUDWidgetInstance)
	{
		APlayerController* PC = Cast<APlayerController>(GetController());
		if (PC && PC->IsLocalController())
		{
			HUDWidgetInstance = CreateWidget<UUserWidget>(PC, HUDWidgetClass);
			if (HUDWidgetInstance)
			{
				HUDWidgetInstance->AddToViewport();
			}
		}
	}

	// Auto-detect max bullets from BulletsBox if present
	TArray<UUserWidget*> Widgets = GetAllHUDWidgets();
	for (UUserWidget* Widget : Widgets)
	{
		if (!Widget) continue;
		if (UPanelWidget* BulletsPanel = Cast<UPanelWidget>(Widget->GetWidgetFromName(FName("BulletsBox"))))
		{
			const int32 NumChildren = BulletsPanel->GetChildrenCount();
			if (NumChildren > 0)
			{
				MaxBullets = NumChildren;
				BulletCounter = NumChildren;
				break;
			}
		}
	}

	HealthCounter = MaxHealth;
	BulletCounter = FMath::Clamp(BulletCounter, 0, MaxBullets);

	UpdateHUD();
	OnStatsChanged();
}


// Called every frame
void AHunterCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void AHunterCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	PlayerInputComponent->BindAxis("MoveForward", this, &AHunterCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AHunterCharacter::MoveRight);
	PlayerInputComponent->BindAxis("Turn", this, &AHunterCharacter::AddControllerYawInput);
	PlayerInputComponent->BindAxis("LookUp", this, &AHunterCharacter::AddControllerPitchInput);
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AHunterCharacter::Jump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &AHunterCharacter::StopJumping);
	PlayerInputComponent->BindAction("Fire", IE_Pressed, this, &AHunterCharacter::Fire);
}

void AHunterCharacter::MoveForward(float value) {
	FVector direction = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::X);
	AddMovementInput(direction, value);
}

void AHunterCharacter::MoveRight(float value) {
	FVector direction = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::Y);
	AddMovementInput(direction, value);
}

void AHunterCharacter::Fire()
{
	if (BulletCounter <= 0)
	{
		return;
	}

	if (ProjectileClass)
	{
		FVector CameraLocation;
		FRotator CameraRotation;
		if (APlayerController* PC = Cast<APlayerController>(GetController()))
		{
			PC->GetPlayerViewPoint(CameraLocation, CameraRotation);
		}
		else
		{
			CameraLocation = CameraComponent ? CameraComponent->GetComponentLocation() : GetPawnViewLocation();
			CameraRotation = GetViewRotation();
		}

		const float MaxAimDistance = 10000.f;
		FVector TraceEnd = CameraLocation + (CameraRotation.Vector() * MaxAimDistance);

		FHitResult Hit;
		FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(FireTrace), true);
		QueryParams.AddIgnoredActor(this);
		QueryParams.bTraceComplex = true;

		// Default aim point if shooting into open sky (3000 units keeps trajectory well-behaved)
		FVector AimPoint = CameraLocation + (CameraRotation.Vector() * 3000.f);

		// 1. Prioritize Object Types so Pawns (enemies) and world geometry are both detected!
		FCollisionObjectQueryParams ObjectQueryParams;
		ObjectQueryParams.AddObjectTypesToQuery(ECC_WorldStatic);
		ObjectQueryParams.AddObjectTypesToQuery(ECC_WorldDynamic);
		ObjectQueryParams.AddObjectTypesToQuery(ECC_Pawn);
		ObjectQueryParams.AddObjectTypesToQuery(ECC_PhysicsBody);

		if (GetWorld()->LineTraceSingleByObjectType(Hit, CameraLocation, TraceEnd, ObjectQueryParams, QueryParams))
		{
			AimPoint = Hit.ImpactPoint;
		}
		// 2. Fallback to Visibility channel (e.g. landscape or special static meshes)
		else if (GetWorld()->LineTraceSingleByChannel(Hit, CameraLocation, TraceEnd, ECC_Visibility, QueryParams))
		{
			AimPoint = Hit.ImpactPoint;
		}
		// 3. Fallback to Camera channel
		else if (GetWorld()->LineTraceSingleByChannel(Hit, CameraLocation, TraceEnd, ECC_Camera, QueryParams))
		{
			AimPoint = Hit.ImpactPoint;
		}

		FVector MuzzleLocation;
		if (GunMeshComponent && GunMeshComponent->DoesSocketExist(TEXT("Muzzle")))
		{
			MuzzleLocation = GunMeshComponent->GetSocketLocation(TEXT("Muzzle"));
		}
		else if (GetMesh() && GetMesh()->DoesSocketExist(TEXT("Muzzle")))
		{
			MuzzleLocation = GetMesh()->GetSocketLocation(TEXT("Muzzle"));
		}
		else if (GunMeshComponent)
		{
			MuzzleLocation = GunMeshComponent->GetComponentTransform().TransformPosition(MuzzleOffset);
		}
		else
		{
			const float DistToAim = FVector::Dist(CameraLocation, AimPoint);
			const float SafeForward = FMath::Clamp(MuzzleOffset.X, 10.f, FMath::Max(DistToAim - 20.f, 10.f));
			MuzzleLocation = CameraLocation + (CameraRotation.Vector() * SafeForward);
		}

		FVector LaunchDirection = (AimPoint - MuzzleLocation).GetSafeNormal();
		FRotator MuzzleRotation = LaunchDirection.Rotation();

		FActorSpawnParameters SpawnParams;
		SpawnParams.Owner = this;
		SpawnParams.Instigator = GetInstigator();
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		AProjectile* Projectile = GetWorld()->SpawnActor<AProjectile>(ProjectileClass, MuzzleLocation, MuzzleRotation, SpawnParams);
		if (Projectile)
		{
			const float DistanceToTarget = FVector::Dist(MuzzleLocation, AimPoint);
			Projectile->FireInDirection(LaunchDirection, DistanceToTarget);

			BulletCounter--;
			UpdateHUD();
			OnStatsChanged();

			OnFireEvent();
		}
	}
}

void AHunterCharacter::OnFireEvent_Implementation()
{

}

TArray<UUserWidget*> AHunterCharacter::GetAllHUDWidgets()
{
	TArray<UUserWidget*> FoundWidgets;
	if (HUDWidgetInstance)
	{
		FoundWidgets.AddUnique(HUDWidgetInstance);
	}

	if (FObjectProperty* Prop = FindFProperty<FObjectProperty>(GetClass(), FName("HUDInstance")))
	{
		if (UUserWidget* BPHud = Cast<UUserWidget>(Prop->GetObjectPropertyValue_InContainer(this)))
		{
			FoundWidgets.AddUnique(BPHud);
			if (!HUDWidgetInstance)
			{
				HUDWidgetInstance = BPHud;
			}
		}
	}

	if (FoundWidgets.Num() == 0 && GetWorld())
	{
		for (TObjectIterator<UUserWidget> It; It; ++It)
		{
			if (It->GetWorld() == GetWorld() && It->IsInViewport() && It->GetClass()->GetName().Contains(TEXT("HUD_Widget")))
			{
				FoundWidgets.AddUnique(*It);
				if (!HUDWidgetInstance)
				{
					HUDWidgetInstance = *It;
				}
			}
		}
	}

	return FoundWidgets;
}

void AHunterCharacter::ApplyDamageDirect(float Amount)
{
	HealthCounter = FMath::Clamp(HealthCounter - Amount, 0.0f, MaxHealth);
	UpdateHUD();
	PlayDamageFlash();
	OnStatsChanged();
}

void AHunterCharacter::AddHealthDirect(float Amount)
{
	HealthCounter = FMath::Clamp(HealthCounter + Amount, 0.0f, MaxHealth);
	UpdateHUD();
	OnStatsChanged();
}

void AHunterCharacter::AddBulletsDirect(int32 Amount)
{
	BulletCounter = FMath::Clamp(BulletCounter + Amount, 0, MaxBullets);
	UpdateHUD();
	OnStatsChanged();
}

void AHunterCharacter::TakeHit_Implementation(float Amount)
{
	PlayDamageFlash();
}

void AHunterCharacter::TakeDamageCustom(float DamageAmount)
{
	ApplyDamageDirect(DamageAmount);
}

void AHunterCharacter::UpdateHUD()
{
	TArray<UUserWidget*> Widgets = GetAllHUDWidgets();
	for (UUserWidget* Widget : Widgets)
	{
		if (!Widget) continue;

		if (UFunction* SetHealthFunc = Widget->FindFunction(FName("SetHealth")))
		{
			struct { double Health; } ParamsDouble = { (double)HealthCounter };
			struct { float Health; } ParamsFloat = { HealthCounter };

			if (FProperty* Prop = SetHealthFunc->FindPropertyByName(FName("Health")))
			{
				if (Prop->IsA<FDoubleProperty>())
				{
					Widget->ProcessEvent(SetHealthFunc, &ParamsDouble);
				}
				else
				{
					Widget->ProcessEvent(SetHealthFunc, &ParamsFloat);
				}
			}
			else
			{
				Widget->ProcessEvent(SetHealthFunc, &ParamsDouble);
			}
		}

		if (UFunction* SetBulletsFunc = Widget->FindFunction(FName("SetBullets")))
		{
			struct { int32 Bullets; } ParamsInt = { BulletCounter };
			struct { int64 Bullets; } ParamsInt64 = { BulletCounter };
			struct { double Bullets; } ParamsDouble = { (double)BulletCounter };

			if (FProperty* Prop = SetBulletsFunc->FindPropertyByName(FName("Bullets")))
			{
				if (Prop->IsA<FDoubleProperty>())
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsDouble);
				}
				else if (Prop->IsA<FInt64Property>())
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsInt64);
				}
				else
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsInt);
				}
			}
			else if (FProperty* PropNum = SetBulletsFunc->FindPropertyByName(FName("BulletNum")))
			{
				if (PropNum->IsA<FDoubleProperty>())
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsDouble);
				}
				else if (PropNum->IsA<FInt64Property>())
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsInt64);
				}
				else
				{
					Widget->ProcessEvent(SetBulletsFunc, &ParamsInt);
				}
			}
			else
			{
				Widget->ProcessEvent(SetBulletsFunc, &ParamsInt);
			}
		}

		if (UProgressBar* BulletsBar = Cast<UProgressBar>(Widget->GetWidgetFromName(FName("BulletsProgressBar"))))
		{
			BulletsBar->SetPercent(FMath::Clamp((float)BulletCounter / (float)MaxBullets, 0.0f, 1.0f));
		}

		// Directly update BulletsBox (Horizontal Box or Wrap Box with bullet icons)
		if (UPanelWidget* BulletsPanel = Cast<UPanelWidget>(Widget->GetWidgetFromName(FName("BulletsBox"))))
		{
			const int32 NumChildren = BulletsPanel->GetChildrenCount();
			for (int32 i = 0; i < NumChildren; ++i)
			{
				if (UWidget* Child = BulletsPanel->GetChildAt(i))
				{
					Child->SetVisibility(i < BulletCounter ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Hidden);
				}
			}
		}

		if (UProgressBar* HealthBar = Cast<UProgressBar>(Widget->GetWidgetFromName(FName("HealthProgressBar"))))
		{
			HealthBar->SetPercent(FMath::Clamp(HealthCounter / MaxHealth, 0.0f, 1.0f));
		}
	}
}

void AHunterCharacter::PlayDamageFlash()
{
	TArray<UUserWidget*> Widgets = GetAllHUDWidgets();
	for (UUserWidget* Widget : Widgets)
	{
		if (!Widget) continue;

		if (UFunction* DamageAnimFunc = Widget->FindFunction(FName("PlayDamageEffect")))
		{
			Widget->ProcessEvent(DamageAnimFunc, nullptr);
		}

		if (UWidgetBlueprintGeneratedClass* WidgetClass = Cast<UWidgetBlueprintGeneratedClass>(Widget->GetClass()))
		{
			for (UWidgetAnimation* Anim : WidgetClass->Animations)
			{
				if (Anim && Anim->GetName().Contains(TEXT("Damage")))
				{
					Widget->PlayAnimation(Anim, 0.0f, 1, EUMGSequencePlayMode::Forward, 1.0f);
					break;
				}
			}
		}
	}
}

void AHunterCharacter::AddHealth_Implementation(float Amount)
{
	AddHealthDirect(Amount);
}

void AHunterCharacter::AddBullets_Implementation(int32 Amount)
{
	AddBulletsDirect(Amount);
}

ETeamAttitude::Type AHunterCharacter::GetTeamAttitudeTowards(const AActor& Other) const
{
	if (const IGenericTeamAgentInterface* OtherTeamAgent = Cast<IGenericTeamAgentInterface>(&Other))
	{
		// Team 0 is player, any other team (e.g. 1) is hostile
		if (OtherTeamAgent->GetGenericTeamId() != GetGenericTeamId())
		{
			return ETeamAttitude::Hostile;
		}
		return ETeamAttitude::Friendly;
	}
	return ETeamAttitude::Neutral;
}

float AHunterCharacter::TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	const float ActualDamage = Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);
	ApplyDamageDirect(ActualDamage);
	return ActualDamage;
}


