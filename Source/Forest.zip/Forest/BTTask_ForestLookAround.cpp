#include "BTTask_ForestLookAround.h"
#include "ForestAIController.h"
#include "GameFramework/Pawn.h"

UBTTask_ForestLookAround::UBTTask_ForestLookAround()
{
	NodeName = TEXT("Forest Look Around & Survey");
}

EBTNodeResult::Type UBTTask_ForestLookAround::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AForestAIController* AIController = Cast<AForestAIController>(OwnerComp.GetAIOwner());
	if (!AIController)
	{
		return EBTNodeResult::Failed;
	}

	APawn* Pawn = AIController->GetPawn();
	if (!Pawn)
	{
		return EBTNodeResult::Failed;
	}

	// Randomly turn to survey forest area
	const float RandomYaw = FMath::RandRange(-LookAroundAngle, LookAroundAngle);
	FRotator NewRot = Pawn->GetActorRotation();
	NewRot.Yaw += RandomYaw;
	Pawn->SetActorRotation(NewRot);

	return EBTNodeResult::Succeeded;
}
