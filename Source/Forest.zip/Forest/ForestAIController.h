#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "Perception/AIPerceptionTypes.h"
#include "ForestAIController.generated.h"

class UAIPerceptionComponent;
class UAISenseConfig_Sight;
class UBehaviorTree;
class UBlackboardData;
class AForestNPCCharacter;

UCLASS()
class FOREST_API AForestAIController : public AAIController
{
	GENERATED_BODY()

public:
	AForestAIController();

	virtual void Tick(float DeltaTime) override;
	virtual ETeamAttitude::Type GetTeamAttitudeTowards(const AActor& Other) const override;

	// Blackboard Key Getters
	const FName& GetPatrolTargetKey() const { return PatrolTargetKey; }
	const FName& GetHasLineOfSightKey() const { return HasLineOfSightKey; }
	const FName& GetDetectedEnemyKey() const { return DetectedEnemyKey; }
	const FName& GetLastKnownLocationKey() const { return LastKnownLocationKey; }
	const FName& GetIsEffectiveRangeKey() const { return IsEffectiveRangeKey; }
	const FName& GetIsDyingKey() const { return IsDyingKey; }
	const FName& GetIsDodgingKey() const { return IsDodgingKey; }
	const FName& GetIsInSmokeKey() const { return IsInSmokeKey; }

	float GetPatrolRadius() const { return PatrolRadius; }
	AActor* GetPerceivedActor() const { return PerceivedActor; }
	bool HasLineOfSight() const { return bHasLineOfSight; }

	// Utility to update smoke status in blackboard
	UFUNCTION(BlueprintCallable, Category = "AI|State")
	void SetInSmoke(bool bInSmoke);

protected:
	virtual void OnPossess(APawn* InPawn) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI|Perception")
	UAIPerceptionComponent* AIPerceptionComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI|Perception")
	UAISenseConfig_Sight* SightConfig;

	// Assets
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Behavior")
	UBehaviorTree* BehaviorTreeAsset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Behavior")
	UBlackboardData* BlackboardAsset;

	// Blackboard Key Names
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName PatrolTargetKey = FName("PatrolTarget");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName HasLineOfSightKey = FName("HasLineOfSight");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName DetectedEnemyKey = FName("DetectedEnemy");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName LastKnownLocationKey = FName("LastKnownLocation");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName IsEffectiveRangeKey = FName("IsEffectiveRange");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName IsDyingKey = FName("IsDying");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName IsDodgingKey = FName("IsDodging");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AI|BlackboardKeys")
	FName IsInSmokeKey = FName("IsInSmoke");

	// Parameters
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Parameters")
	float PatrolRadius = 1600.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Parameters")
	float TargetLostTime = 3.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Parameters")
	float LastLocationUpdateTime = 0.4f;

	UFUNCTION()
	void OnTargetPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus);

private:
	UPROPERTY()
	AActor* PerceivedActor = nullptr;

	UPROPERTY()
	AForestNPCCharacter* ControlledNPC = nullptr;

	bool bHasLineOfSight = false;
	float TargetLostElapsed = 0.0f;
	float LastLocationElapsed = 0.0f;
};
