#include "SmokeHazardArea.h"
#include "Components/SphereComponent.h"
#include "NiagaraComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "ForestNPCCharacter.h"
#include "ForestAIController.h"
#include "HunterCharacter.h"

ASmokeHazardArea::ASmokeHazardArea()
{
	PrimaryActorTick.bCanEverTick = false;

	TriggerSphere = CreateDefaultSubobject<USphereComponent>(TEXT("TriggerSphere"));
	RootComponent = TriggerSphere;
	TriggerSphere->InitSphereRadius(350.0f);
	TriggerSphere->SetCollisionProfileName(TEXT("Trigger"));
	TriggerSphere->SetGenerateOverlapEvents(true);

	SmokeNiagaraComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("SmokeNiagaraComponent"));
	SmokeNiagaraComponent->SetupAttachment(RootComponent);
	SmokeNiagaraComponent->bAutoActivate = true;

	SmokeCascadeComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("SmokeCascadeComponent"));
	SmokeCascadeComponent->SetupAttachment(RootComponent);
	SmokeCascadeComponent->bAutoActivate = false;
}

void ASmokeHazardArea::BeginPlay()
{
	Super::BeginPlay();

	TriggerSphere->OnComponentBeginOverlap.AddDynamic(this, &ASmokeHazardArea::OnOverlapBegin);
	TriggerSphere->OnComponentEndOverlap.AddDynamic(this, &ASmokeHazardArea::OnOverlapEnd);
}

void ASmokeHazardArea::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor || OtherActor == this)
	{
		return;
	}

	// NPC entered poisonous smoke / blind zone
	if (AForestNPCCharacter* NPC = Cast<AForestNPCCharacter>(OtherActor))
	{
		NPC->ApplySmokeDebuff(SpeedPenaltyFactor, bBlindPerception);

		if (AForestAIController* AIC = Cast<AForestAIController>(NPC->GetController()))
		{
			AIC->SetInSmoke(true);
		}

		BP_OnActorEnteredSmoke(NPC);
	}
	// Player entered smoke
	else if (AHunterCharacter* Player = Cast<AHunterCharacter>(OtherActor))
	{
		BP_OnActorEnteredSmoke(Player);
	}
}

void ASmokeHazardArea::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (!OtherActor || OtherActor == this)
	{
		return;
	}

	// NPC exited smoke zone
	if (AForestNPCCharacter* NPC = Cast<AForestNPCCharacter>(OtherActor))
	{
		NPC->RemoveSmokeDebuff();

		if (AForestAIController* AIC = Cast<AForestAIController>(NPC->GetController()))
		{
			AIC->SetInSmoke(false);
		}

		BP_OnActorExitedSmoke(NPC);
	}
	// Player exited smoke
	else if (AHunterCharacter* Player = Cast<AHunterCharacter>(OtherActor))
	{
		BP_OnActorExitedSmoke(Player);
	}
}
