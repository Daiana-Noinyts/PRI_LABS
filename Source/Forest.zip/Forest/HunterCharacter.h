#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GenericTeamAgentInterface.h"
#include "HunterCharacter.generated.h"

UCLASS()
class FOREST_API AHunterCharacter : public ACharacter, public IGenericTeamAgentInterface
{
	GENERATED_BODY()

public:
	AHunterCharacter();

	// IGenericTeamAgentInterface
	virtual FGenericTeamId GetGenericTeamId() const override { return FGenericTeamId(0); }
	virtual ETeamAttitude::Type GetTeamAttitudeTowards(const AActor& Other) const override;

	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
	float HealthCounter = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
	float MaxHealth = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
	int32 BulletCounter = 10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
	int32 MaxBullets = 10;

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "Stats")
	void AddHealth(float Amount);

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "Stats")
	void AddBullets(int32 Amount);


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSubclassOf<class UUserWidget> HUDWidgetClass;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "UI")
	class UUserWidget* HUDWidgetInstance;

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "Combat")
	void TakeHit(float Amount);

	UFUNCTION(BlueprintCallable, Category = "Combat")
	void ApplyDamageDirect(float Amount);

	UFUNCTION(BlueprintCallable, Category = "Stats")
	void AddHealthDirect(float Amount);

	UFUNCTION(BlueprintCallable, Category = "Stats")
	void AddBulletsDirect(int32 Amount);

	UFUNCTION(BlueprintCallable, Category = "UI")
	void UpdateHUD();

	UFUNCTION(BlueprintCallable, Category = "UI")
	void PlayDamageFlash();

	UFUNCTION(BlueprintCallable, Category = "Stats")
	void TakeDamageCustom(float DamageAmount);

	UFUNCTION(BlueprintImplementableEvent, Category = "Stats")
	void OnStatsChanged();

	TArray<class UUserWidget*> GetAllHUDWidgets();




protected:
	virtual void BeginPlay() override;
	void MoveForward(float value);
	void MoveRight(float value);

	UFUNCTION()
	void Fire();

	UPROPERTY(VisibleAnywhere)
	UCameraComponent* CameraComponent;

	UPROPERTY(VisibleAnywhere)
	class UStaticMeshComponent* GunMeshComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector MuzzleOffset = FVector(30.f, 0.0f, 0.0f);

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class AProjectile> ProjectileClass;

public:

	UFUNCTION(BlueprintNativeEvent, Category = "Weapon")
	void OnFireEvent();

	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
};